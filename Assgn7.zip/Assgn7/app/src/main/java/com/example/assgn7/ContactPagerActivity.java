package com.example.assgn7;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.List;
import java.util.UUID;

public class ContactPagerActivity extends AppCompatActivity {
    private ViewPager mViewPager;
    private List<Contact> mContacts;
    private static final String EXTRA_CONTACT_ID = "com.example.assgn7.contact_id";

    @Override
    protected void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.activity_contact_pager);

        mViewPager = (ViewPager)findViewById(R.id.contact_view_pager);
        mContacts = ContactSingleton.get(this).getContacts();
        FragmentManager fragmentManager = getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            @Override
            public Fragment getItem(int position) {
                Contact contact = mContacts.get(position);
                return ContactFragment.newInstance(contact.getID());
            }

            @Override
            public int getCount() {
                return mContacts.size();
            }
        });

        UUID crimeId = (UUID)getIntent().getSerializableExtra(EXTRA_CONTACT_ID);

        for(int i = 0; i < mContacts.size(); i++) {
            if(mContacts.get(i).getID().equals(crimeId)) {
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }

    public static Intent newIntent(Context packageContext, UUID crimeId) {
        Intent intent = new Intent(packageContext, ContactPagerActivity.class);
        intent.putExtra(EXTRA_CONTACT_ID, crimeId);
        return intent;
    }
}
