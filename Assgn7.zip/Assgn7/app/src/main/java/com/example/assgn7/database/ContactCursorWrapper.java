package com.example.assgn7.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.example.assgn7.Contact;

import java.util.UUID;

public class ContactCursorWrapper extends CursorWrapper {
    public ContactCursorWrapper(Cursor cursor){ super(cursor); }
    public Contact getContact(){
        String uuidString = getString(getColumnIndex(ContactDbSchema.ContactTable.Cols.UUID)),
                name = getString(getColumnIndex(ContactDbSchema.ContactTable.Cols.NAME)),
                number = getString(getColumnIndex(ContactDbSchema.ContactTable.Cols.NUMBER)),
                email = getString(getColumnIndex(ContactDbSchema.ContactTable.Cols.EMAIL));

        Contact contact = new Contact(UUID.fromString(uuidString));
        contact.setName(name);
        contact.setNumber(number);
        contact.setEmail(email);

        return contact;
    }
}
