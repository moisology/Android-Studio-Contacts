package com.example.assgn7.database;

public class ContactDbSchema {
    public static final class ContactTable{
        public static final String NAME = "contacts";
        public static final class Cols{
            public static final String UUID = "uuid", NAME = "name", NUMBER = "number", EMAIL = "email";
        }
    }
}
