package com.example.assgn7;

import java.util.UUID;

public class Contact {
    private UUID mId;
    private String mName, mNumber, mEmail;
    public Contact() {
        this(UUID.randomUUID());
        mName = mNumber = mEmail = "";
    }

    public Contact(UUID id){
        mId = id;
    }

    public UUID getID() {
        return mId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getNumber() {
        return mNumber;
    }

    public void setNumber(String number) {
        mNumber = number;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

}
