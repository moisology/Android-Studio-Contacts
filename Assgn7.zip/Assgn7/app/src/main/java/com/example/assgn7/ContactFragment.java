package com.example.assgn7;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.UUID;

public class ContactFragment extends Fragment {
    private TextView mNameTextView,mNumberTextView,mEmailTextView;
    private Contact mContact;
    // an argument to add to the bundle
    private static final String ARG_CONTACT_ID = "contact_id";
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_contact_menu, menu);
    }

    // Override the callback to handle the user's menu selection
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.remove_contact:            // this is the id of the menu option selected
                removeFromList();
                getActivity().onBackPressed();
                return true;                // Tells the OS we're done, nothing further needed
            default:    // if the selected option isn't found, defer to the superclass
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID contactId = (UUID)getArguments().getSerializable(ARG_CONTACT_ID);
        setHasOptionsMenu(true);
        mContact = ContactSingleton.get(getActivity()).getContact(contactId);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode != Activity.RESULT_OK)
            return;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_contact, container, false);                     // view gets added in view activity's code.
        mNameTextView = (TextView) v.findViewById(R.id.contact_name);
        mNameTextView.setText(mContact.getName());
        mNumberTextView = (TextView) v.findViewById(R.id.contact_number);
        mNumberTextView.setText(mContact.getNumber());
        mEmailTextView = (TextView) v.findViewById(R.id.contact_email);
        mEmailTextView.setText(mContact.getEmail());
        return v;
    }

    public static ContactFragment newInstance(UUID contactId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_CONTACT_ID, contactId);
        ContactFragment fragment = new ContactFragment();
        fragment.setArguments(args);
        return fragment;
    }


    void removeFromList(){ ContactSingleton.get(getActivity()).removeContact(mContact); }
}
