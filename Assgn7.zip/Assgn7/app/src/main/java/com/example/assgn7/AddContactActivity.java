package com.example.assgn7;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddContactActivity extends AppCompatActivity {
    private Contact mContact;           // a crime object reference.
    private EditText mNameField, mNumberField, mEmailField;   // an EditText reference
    private Button mCancelButton, mAddButton;
    @Override
    public void onPause(){
        super.onPause();
        ContactSingleton.get(this).updateContact(mContact);
    }
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_contact);

        mContact = new Contact();
        mNameField = (EditText) findViewById(R.id.contact_name);
        mNameField.setText(mContact.getName());
        mNameField.addTextChangedListener(new TextWatcher() { // set listener
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mContact.setName(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
        mNumberField = (EditText) findViewById(R.id.contact_number);
        mNumberField.setText(mContact.getNumber());
        mNumberField.addTextChangedListener(new TextWatcher() { // set listener
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mContact.setNumber(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
        mEmailField = (EditText) findViewById(R.id.contact_email);
        mEmailField.setText(mContact.getEmail());
        mEmailField.addTextChangedListener(new TextWatcher() { // set listener
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mContact.setEmail(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
        mAddButton = (Button) findViewById(R.id.add_button);
        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addContact();
                onBackPressed();
            }
        });
        mCancelButton = (Button) findViewById(R.id.cancel_button);
        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    public static Intent newIntent(Context packageContext){
        Intent intent = new Intent(packageContext, AddContactActivity.class);
        return intent;
    }
    public void addContact(){ ContactSingleton.get(this).addContact(mContact); }
}
