package com.example.assgn7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assgn7.database.ContactCursorWrapper;
import com.example.assgn7.database.ContactDbSchema.ContactTable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactSingleton {
    private static ContactSingleton sContactLab;
    //private List<Contact> mContacts;
    private Context mContext;
    private SQLiteDatabase mDataBase;

    public static ContactSingleton get(Context context) {
        if(sContactLab == null)
            sContactLab = new ContactSingleton(context);
        return sContactLab;
    }

    public ContactSingleton(){}

    private ContactSingleton(Context context) {
        mContext = context.getApplicationContext();
        mDataBase = new ContactBaseHelper(mContext).getWritableDatabase();
        //mContacts = new ArrayList<>();
    }

    //public ContactSingleton(List<Contact> contacts){
    //
    //}

    public void addContact(Contact c) {
        ContentValues values = getContentContentValues(c);
        mDataBase.insert(ContactTable.NAME,null,values);
    }

    public void removeContact(Contact c){
        mDataBase.delete(ContactTable.NAME, ContactTable.Cols.UUID + " = ?",
                new String[]{String.valueOf(c.getID())});
    }

    public List<Contact> getContacts() {
        List<Contact> contacts = new ArrayList<>();
        ContactCursorWrapper cursor = queryContacts(null,null);
        try{
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                contacts.add(cursor.getContact());
                cursor.moveToNext();
            }
        }
        finally{ cursor.close(); }
        return contacts;
    }

    public Contact getContact(UUID id) {
        ContactCursorWrapper cursor = queryContacts(ContactTable.Cols.UUID + " = ?",
                new String[] {id.toString()});
        try{
            if(cursor.getCount() == 0){return null; }
            cursor.moveToFirst();
            return cursor.getContact();
        }
        finally { cursor.close(); }
    }

    public void updateContact(Contact contact){
        String uuidString = contact.getID().toString();
        ContentValues values = getContentContentValues(contact);
        mDataBase.update(ContactTable.NAME, values, ContactTable.Cols.UUID + " = ?",
                new String[] {uuidString} );
    }

    private static ContentValues getContentContentValues(Contact contact){
        ContentValues values = new ContentValues();
        values.put(ContactTable.Cols.UUID, contact.getID().toString());
        values.put(ContactTable.Cols.NAME, contact.getName());
        values.put(ContactTable.Cols.NUMBER, contact.getNumber());
        values.put(ContactTable.Cols.EMAIL, contact.getEmail());
        return values;
    }

    private ContactCursorWrapper queryContacts(String whereClause, String[] whereArgs){
        Cursor cursor = mDataBase.query(ContactTable.NAME, null, whereClause,
                whereArgs, null, null, null);
        return new ContactCursorWrapper(cursor);
    }

    public Contact getContact(int i){ return getContacts().get(i); }

    public UUID getBaseID(){ return getContacts().get(0).getID(); }

    public boolean isEmpty(){ return getContacts().isEmpty(); }
}
