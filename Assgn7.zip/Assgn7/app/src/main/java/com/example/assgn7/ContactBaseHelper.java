package com.example.assgn7;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.assgn7.database.ContactDbSchema.ContactTable;


public class ContactBaseHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "contactBase.db";
    public ContactBaseHelper(Context context){ super(context, DATABASE_NAME, null, VERSION); }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + ContactTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                ContactTable.Cols.UUID + ", " +
                ContactTable.Cols.NAME + ", " +
                ContactTable.Cols.NUMBER + ", " +
                ContactTable.Cols.EMAIL + ")");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}
}
