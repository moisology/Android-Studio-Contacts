package com.example.assgn7;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.List;
import java.util.UUID;

public class ContactMenuFragment extends Fragment {
    private Button mViewContacts, mAddContact;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_menu_contact, container, false);
        mViewContacts = (Button) v.findViewById(R.id.view_contacts);
        mViewContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!emptySingleton()){
                    Intent intent = ContactPagerActivity.newIntent(getActivity(),getBaseID());
                    startActivity(intent);
                }
            }
        });
        mAddContact = (Button) v.findViewById(R.id.add_contact);
        mAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = AddContactActivity.newIntent(getActivity());
                startActivity(intent);
            }
        });
        return v;
    }

    boolean emptySingleton(){ return ContactSingleton.get(getActivity()).isEmpty(); }
    UUID getBaseID(){ return ContactSingleton.get(getActivity()).getBaseID(); }
}
